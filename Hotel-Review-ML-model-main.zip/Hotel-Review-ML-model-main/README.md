# Hotel-Review-ML-model
It analyzes the present reviews of a hotel, trains the ML model and then classifies the further reviews as positive or negative sentiments about the hotel. It uses Natural Language Processing(NLP) in predicting hotel review sentiments and furthermore concludes the model via graphical representation.
